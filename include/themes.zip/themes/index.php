<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2004-2023 The Canaris                                     |
 |                                                                         |
 +-------------------------------------------------------------------------+
 | NMS: The Complete RRDtool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by the Canaris. See      |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
 | http://www.canaris.in/                                                   |
 +-------------------------------------------------------------------------+
*/

header('Location:../index.php');
